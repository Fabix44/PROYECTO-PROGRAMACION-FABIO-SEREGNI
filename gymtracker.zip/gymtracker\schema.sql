-- ============================================
-- Base de datos: GymTracker
-- Tabla: entrenamientos
-- ============================================

DROP TABLE IF EXISTS entrenamientos;

CREATE TABLE entrenamientos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ejercicio TEXT NOT NULL,
    grupo_muscular TEXT NOT NULL,
    peso_kg REAL NOT NULL,
    series INTEGER NOT NULL,
    repeticiones INTEGER NOT NULL,
    fecha TEXT NOT NULL,
    notas TEXT
);

-- ============================================
-- Registros de prueba (mínimo 3, aquí van 5)
-- ============================================

INSERT INTO entrenamientos (ejercicio, grupo_muscular, peso_kg, series, repeticiones, fecha, notas) VALUES
('Press de banca', 'Pecho', 80.0, 4, 10, '2026-10-01', 'Buena sesión, subí 5kg'),
('Sentadilla', 'Pierna', 100.0, 5, 8, '2026-10-02', 'Fallo en la última serie'),
('Peso muerto', 'Espalda', 120.0, 3, 6, '2026-10-03', 'Técnica mejorada'),
('Curl de bíceps', 'Bíceps', 20.0, 4, 12, '2026-10-04', 'Bombeo brutal'),
('Press militar', 'Hombro', 50.0, 4, 10, '2026-10-05', 'Hombro cargado');


-- ============================================
-- Tabla: rutinas
-- Plantillas reutilizables de entrenamiento
-- ============================================

DROP TABLE IF EXISTS rutinas;

CREATE TABLE rutinas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    descripcion TEXT,
    ejercicios TEXT NOT NULL,
    notas TEXT
);

-- ============================================
-- Registros de prueba para rutinas
-- ============================================

INSERT INTO rutinas (nombre, descripcion, ejercicios, notas) VALUES
('Día de empuje', 'Pecho, hombro y tríceps', 'Press banca|Fondos|Press militar|Extensión de tríceps', 'Enfocado en fuerza'),
('Día de tirón', 'Espalda y bíceps', 'Dominadas|Remo con barra|Curl bíceps|Curl martillo', 'Buena para volumen'),
('Día de pierna', 'Cuádriceps, femoral y glúteo', 'Sentadilla|Peso muerto|Prensa|Extensión de cuádriceps', 'Día pesado');