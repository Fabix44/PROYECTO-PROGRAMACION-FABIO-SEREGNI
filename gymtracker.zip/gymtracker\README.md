# GymTracker

Aplicación web CRUD para el registro y seguimiento de entrenamientos de gimnasio, desarrollada con Flask (Python) y SQLite3, con interfaz responsiva en HTML5, CSS3 y JavaScript vanilla.

---

## Descripción del Proyecto

**GymTracker** resuelve el problema de llevar un registro ordenado de las sesiones de entrenamiento. Permite a cualquier persona que entrene en el gimnasio:

- 📝 Registrar cada ejercicio realizado con su peso, series y repeticiones.
- 📊 Visualizar estadísticas automáticas: total de entrenamientos, volumen total levantado y ejercicio más pesado.
- ✏️ Editar cualquier registro existente.
- 🗑️ Eliminar registros con confirmación previa para evitar errores.
- 🔍 Filtrar los entrenamientos por grupo muscular (Pecho, Espalda, Pierna, etc.).

El **volumen total** de cada ejercicio se calcula automáticamente con la fórmula:
> `volumen = peso_kg × series × repeticiones`

---

## 🛠️ Tecnologías Utilizadas

| Capa | Tecnología |
|------|------------|
| **Backend** | Python 3 + Flask |
| **Base de datos** | SQLite3 (librería nativa, consultas parametrizadas) |
| **Frontend** | HTML5 + CSS3 + JavaScript (Vanilla JS) |
| **Motor de plantillas** | Jinja2 |

---

## 📂 Estructura del Proyecto

## ⚙️ Instalación y Ejecución

### 1. Descargar y descomprimir el proyecto
Extrae el contenido del archivo `.zip` en la ubicación que prefieras.

### 2. Abrir una terminal en la carpeta del proyecto

**Windows:** Click derecho dentro de la carpeta → "Abrir en Terminal" o "Abrir en PowerShell"
**Mac/Linux:** Abrir Terminal y navegar con `cd` hasta la carpeta

### 3. Crear un entorno virtual (recomendado)

**Windows:**
```powershell
python -m venv .venv
.\.venv\Scripts\activate
```

### 4.Instalar las dependencias

```bash
pip install -r requirements.txt

```

### 5.Inicializar la base de datos
```bash
python init_db.py
```
### 6.  Ejecutar el servidor
```bash
python app.py
```

### 7. Abrir en el navegador
```bash
http://127.0.0.1:5000
```