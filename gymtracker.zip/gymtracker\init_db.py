# init_db.py - Inicializa la base de datos desde schema.sql
import sqlite3

conn = sqlite3.connect('database.db')
with open('schema.sql', encoding='utf-8') as f:
    conn.executescript(f.read())
conn.commit()
conn.close()

print('✅ Base de datos inicializada correctamente')