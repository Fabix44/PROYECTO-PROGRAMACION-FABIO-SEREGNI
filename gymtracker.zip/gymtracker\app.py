
# GymTracker - Aplicación 


from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
import os


app = Flask(__name__)
app.secret_key = 'gymtracker_secret_key_2026'  


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, 'database.db')



def get_db_connection():
    """Abre una conexión a SQLite3 y permite acceder a las columnas por nombre."""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  
    return conn


# --------------------------------------------
# RUTA 1: Página principal (READ)
# --------------------------------------------
@app.route('/')
def index():
    conn = get_db_connection()
    entrenamientos = conn.execute('SELECT * FROM entrenamientos ORDER BY fecha DESC').fetchall()
    
    
    stats = {
        'total': len(entrenamientos),
        'volumen_total': 0,
        'ejercicio_mas_pesado': None,
        'peso_max': 0
    }
    
    for e in entrenamientos:
        volumen = e['peso_kg'] * e['series'] * e['repeticiones']
        stats['volumen_total'] += volumen
        if e['peso_kg'] > stats['peso_max']:
            stats['peso_max'] = e['peso_kg']
            stats['ejercicio_mas_pesado'] = e['ejercicio']
    
    conn.close()
    return render_template('index.html', entrenamientos=entrenamientos, stats=stats)


# --------------------------------------------
# RUTA 2: Crear entrenamiento (CREATE - GET y POST)
# --------------------------------------------
@app.route('/crear', methods=['GET', 'POST'])
def crear():
    if request.method == 'POST':
        
        ejercicio = request.form['ejercicio']
        grupo_muscular = request.form['grupo_muscular']
        peso_kg = request.form['peso_kg']
        series = request.form['series']
        repeticiones = request.form['repeticiones']
        fecha = request.form['fecha']
        notas = request.form.get('notas', '')

        
        if not ejercicio or not grupo_muscular or not peso_kg or not series or not repeticiones or not fecha:
            flash('Todos los campos obligatorios deben estar completos', 'error')
            return redirect(url_for('crear'))

        
        conn = get_db_connection()
        conn.execute(
            'INSERT INTO entrenamientos (ejercicio, grupo_muscular, peso_kg, series, repeticiones, fecha, notas) VALUES (?, ?, ?, ?, ?, ?, ?)',
            (ejercicio, grupo_muscular, peso_kg, series, repeticiones, fecha, notas)
        )
        conn.commit()
        conn.close()

        flash('Entrenamiento registrado exitosamente 💪', 'success')
        return redirect(url_for('index'))

    return render_template('crear.html')


# --------------------------------------------
# RUTA 3: Editar entrenamiento (UPDATE - GET y POST)
# --------------------------------------------
@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    conn = get_db_connection()
    entrenamiento = conn.execute('SELECT * FROM entrenamientos WHERE id = ?', (id,)).fetchone()

    if entrenamiento is None:
        conn.close()
        flash('Entrenamiento no encontrado', 'error')
        return redirect(url_for('index'))

    if request.method == 'POST':
        ejercicio = request.form['ejercicio']
        grupo_muscular = request.form['grupo_muscular']
        peso_kg = request.form['peso_kg']
        series = request.form['series']
        repeticiones = request.form['repeticiones']
        fecha = request.form['fecha']
        notas = request.form.get('notas', '')

        if not ejercicio or not grupo_muscular or not peso_kg or not series or not repeticiones or not fecha:
            flash('Todos los campos obligatorios deben estar completos', 'error')
            return redirect(url_for('editar', id=id))

        conn.execute(
            '''UPDATE entrenamientos 
               SET ejercicio = ?, grupo_muscular = ?, peso_kg = ?, series = ?, repeticiones = ?, fecha = ?, notas = ?
               WHERE id = ?''',
            (ejercicio, grupo_muscular, peso_kg, series, repeticiones, fecha, notas, id)
        )
        conn.commit()
        conn.close()

        flash('Entrenamiento actualizado correctamente ✅', 'success')
        return redirect(url_for('index'))

    conn.close()
    return render_template('editar.html', entrenamiento=entrenamiento)


# --------------------------------------------
# RUTA 4: Eliminar entrenamiento (DELETE)
# --------------------------------------------
@app.route('/eliminar/<int:id>', methods=['POST'])
def eliminar(id):
    conn = get_db_connection()
    entrenamiento = conn.execute('SELECT * FROM entrenamientos WHERE id = ?', (id,)).fetchone()

    if entrenamiento is None:
        conn.close()
        flash('Entrenamiento no encontrado', 'error')
        return redirect(url_for('index'))

    conn.execute('DELETE FROM entrenamientos WHERE id = ?', (id,))
    conn.commit()
    conn.close()

    flash('Entrenamiento eliminado 🗑️', 'success')
    return redirect(url_for('index'))



# --------------------------------------------
# RUTA 5: Listar todas las rutinas (READ)
# --------------------------------------------
@app.route('/rutinas')
def rutinas():
    conn = get_db_connection()
    rutinas_db = conn.execute('SELECT * FROM rutinas ORDER BY id ASC').fetchall()
    conn.close()
    return render_template('rutinas.html', rutinas=rutinas_db)


# --------------------------------------------
# RUTA 6: Crear rutina (CREATE - GET y POST)
# --------------------------------------------
@app.route('/rutinas/crear', methods=['GET', 'POST'])
def crear_rutina():
    if request.method == 'POST':
        nombre = request.form['nombre']
        descripcion = request.form.get('descripcion', '')
        notas = request.form.get('notas', '')

        
        ejercicios_lista = request.form.getlist('ejercicios[]')
        
        ejercicios_lista = [e.strip() for e in ejercicios_lista if e.strip()]
        
        ejercicios = '|'.join(ejercicios_lista)

        
        if not nombre or not ejercicios:
            flash('El nombre y al menos un ejercicio son obligatorios', 'error')
            return redirect(url_for('crear_rutina'))

        conn = get_db_connection()
        conn.execute(
            'INSERT INTO rutinas (nombre, descripcion, ejercicios, notas) VALUES (?, ?, ?, ?)',
            (nombre, descripcion, ejercicios, notas)
        )
        conn.commit()
        conn.close()

        flash('Rutina creada exitosamente 💪', 'success')
        return redirect(url_for('rutinas'))

    return render_template('crear_rutina.html')


# --------------------------------------------
# RUTA 7: Editar rutina (UPDATE - GET y POST)
# --------------------------------------------
@app.route('/rutinas/editar/<int:id>', methods=['GET', 'POST'])
def editar_rutina(id):
    conn = get_db_connection()
    rutina = conn.execute('SELECT * FROM rutinas WHERE id = ?', (id,)).fetchone()

    if rutina is None:
        conn.close()
        flash('Rutina no encontrada', 'error')
        return redirect(url_for('rutinas'))

    if request.method == 'POST':
        nombre = request.form['nombre']
        descripcion = request.form.get('descripcion', '')
        notas = request.form.get('notas', '')

        ejercicios_lista = request.form.getlist('ejercicios[]')
        ejercicios_lista = [e.strip() for e in ejercicios_lista if e.strip()]
        ejercicios = '|'.join(ejercicios_lista)

        if not nombre or not ejercicios:
            flash('El nombre y al menos un ejercicio son obligatorios', 'error')
            return redirect(url_for('editar_rutina', id=id))

        conn.execute(
            'UPDATE rutinas SET nombre = ?, descripcion = ?, ejercicios = ?, notas = ? WHERE id = ?',
            (nombre, descripcion, ejercicios, notas, id)
        )
        conn.commit()
        conn.close()

        flash('Rutina actualizada correctamente ✅', 'success')
        return redirect(url_for('rutinas'))

    conn.close()
    return render_template('editar_rutina.html', rutina=rutina)


# --------------------------------------------
# RUTA 8: Eliminar rutina (DELETE)
# --------------------------------------------

@app.route('/rutinas/eliminar/<int:id>', methods=['POST'])
def eliminar_rutina(id):
    conn = get_db_connection()
    rutina = conn.execute('SELECT * FROM rutinas WHERE id = ?', (id,)).fetchone()

    if rutina is None:
        conn.close()
        flash('Rutina no encontrada', 'error')
        return redirect(url_for('rutinas'))

    conn.execute('DELETE FROM rutinas WHERE id = ?', (id,))
    conn.commit()
    conn.close()

    flash('Rutina eliminada 🗑️', 'success')
    return redirect(url_for('rutinas'))
# --------------------------------------------
# Punto de entrada
# --------------------------------------------
if __name__ == '__main__':
    app.run(debug=True)