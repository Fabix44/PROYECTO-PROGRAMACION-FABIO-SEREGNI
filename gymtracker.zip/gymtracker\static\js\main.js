/* ============================================
   GymTracker — JavaScript principal
   ============================================ */


document.addEventListener('DOMContentLoaded', function () {

    
    // 1. CONFIRMACIÓN ANTES DE ELIMINAR (obligatorio)
    
    const formulariosEliminar = document.querySelectorAll('.form-eliminar');

    formulariosEliminar.forEach(function (form) {
        form.addEventListener('submit', function (e) {
            const ejercicio = form.getAttribute('data-ejercicio') || 'este entrenamiento';
            const confirmar = confirm(
                '⚠️ ¿Estás seguro de que quieres eliminar "' + ejercicio + '"?\n\nEsta acción no se puede deshacer.'
            );

            if (!confirmar) {
                e.preventDefault(); // Cancela el envío del formulario
            }
        });
    });

    
    // 2. FILTRO POR GRUPO MUSCULAR
    
    const botonesFiltro = document.querySelectorAll('.filtro-btn');
    const cards = document.querySelectorAll('.card');

    botonesFiltro.forEach(function (boton) {
        boton.addEventListener('click', function () {
            // Quitar "active" de todos los botones
            botonesFiltro.forEach(function (b) {
                b.classList.remove('active');
            });
            // Poner "active" solo al botón clickeado
            boton.classList.add('active');

            const filtro = boton.getAttribute('data-filtro');

            // Mostrar u ocultar cards
            cards.forEach(function (card) {
                const grupo = card.getAttribute('data-grupo');

                if (filtro === 'todos' || grupo === filtro) {
                    card.style.display = 'flex';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });

    
    // 3. AUTOCOMPLETAR FECHA DE HOY EN EL FORMULARIO
    
    const inputFecha = document.getElementById('fecha');

    // Solo si estamos en el formulario de CREAR (no en el de editar)
    if (inputFecha && document.getElementById('form-crear')) {
        const hoy = new Date().toISOString().split('T')[0];
        inputFecha.value = hoy;
    }

    
    // 4. AUTO-OCULTAR MENSAJES FLASH DESPUÉS DE 4 SEGUNDOS
   
    const mensajesFlash = document.querySelectorAll('.flash');

    mensajesFlash.forEach(function (mensaje) {
        setTimeout(function () {
            mensaje.style.transition = 'opacity 0.5s, transform 0.5s';
            mensaje.style.opacity = '0';
            mensaje.style.transform = 'translateY(-10px)';
            setTimeout(function () {
                mensaje.remove();
            }, 500);
        }, 4000);
    });
    
    // 5. SISTEMA DINÁMICO DE EJERCICIOS EN RUTINAS
    
    
    const ejerciciosContainer = document.getElementById('ejercicios-container');
    const btnAgregarEjercicio = document.getElementById('btn-agregar-ejercicio');

    // Función para crear un nuevo input de ejercicio
    function crearInputEjercicio(valor = '') {
        const div = document.createElement('div');
        div.className = 'ejercicio-input-row';

        const input = document.createElement('input');
        input.type = 'text';
        input.name = 'ejercicios[]';
        input.className = 'ejercicio-input';
        input.placeholder = 'Ej: Press de banca';
        input.value = valor;

        const btnQuitar = document.createElement('button');
        btnQuitar.type = 'button';
        btnQuitar.className = 'btn-quitar-ejercicio';
        btnQuitar.textContent = '✕';
        btnQuitar.title = 'Quitar este ejercicio';

        btnQuitar.addEventListener('click', function () {
            // Solo permitir quitar si hay más de 1 input
            const totalInputs = ejerciciosContainer.querySelectorAll('.ejercicio-input').length;
            if (totalInputs > 1) {
                div.remove();
            } else {
                alert('Debe haber al menos un ejercicio');
            }
        });

        div.appendChild(input);
        div.appendChild(btnQuitar);
        return div;
    }

    // Botón "+ Agregar otro ejercicio"
    if (btnAgregarEjercicio && ejerciciosContainer) {
        btnAgregarEjercicio.addEventListener('click', function () {
            const nuevoInput = crearInputEjercicio();
            ejerciciosContainer.appendChild(nuevoInput);
            // Enfocar el nuevo input
            nuevoInput.querySelector('.ejercicio-input').focus();
        });
    }

    // 🔥 Truco: detectar si el usuario escribe varios ejercicios separados con "|"
    if (ejerciciosContainer) {
        ejerciciosContainer.addEventListener('input', function (e) {
            if (e.target.classList.contains('ejercicio-input')) {
                const valor = e.target.value;

                // Si contiene "|" y no es solo un "|"
                if (valor.includes('|')) {
                    const partes = valor.split('|').map(p => p.trim()).filter(p => p !== '');

                    if (partes.length > 1) {
                        // El primer input mantiene el primer ejercicio
                        e.target.value = partes[0];

                        // Los demás se agregan como nuevos inputs
                        for (let i = 1; i < partes.length; i++) {
                            const nuevoInput = crearInputEjercicio(partes[i]);
                            ejerciciosContainer.appendChild(nuevoInput);
                        }
                    }
                }
            }
        });
    }

   
    // 6. CONFIRMACIÓN ANTES DE ELIMINAR RUTINAS
    
    const formulariosEliminarRutina = document.querySelectorAll('.form-eliminar-rutina');

    formulariosEliminarRutina.forEach(function (form) {
        form.addEventListener('submit', function (e) {
            const nombre = form.getAttribute('data-nombre') || 'esta rutina';
            const confirmar = confirm(
                '⚠️ ¿Estás seguro de que quieres eliminar la rutina "' + nombre + '"?\n\nEsta acción no se puede deshacer.'
            );

            if (!confirmar) {
                e.preventDefault();
            }
        });
    });
});